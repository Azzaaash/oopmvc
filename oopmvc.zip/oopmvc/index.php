<?php
// file: oopmvc/index.php
require_once 'controller/Anggota.php';

$controller = new Anggota();

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id = isset($_GET['id']) ? $_GET['id'] : null; // Perbaiki 'Id' menjadi 'id'
    
    switch($action) {
        case 'create':
            $controller->create();
            break;
        case 'edit':
            $controller->edit($id);
            break;
        case 'delete':
            $controller->delete($id);
            break;
        case 'detail':
            $controller->detail($id);
            break;
        default:
            $controller->index();
            break;
    }
} else {
    $controller->index();
}
?>
