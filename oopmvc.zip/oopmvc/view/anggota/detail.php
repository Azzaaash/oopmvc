<div class="card">
    <div class="card-header">
        <h2>Detail Anggota</h2>
    </div>
    <div class="card-body">
        <?php if ($data): ?>
            <p><strong>ID:</strong> <?php echo $data['id']; ?></p>
            <p><strong>Nama:</strong> <?php echo $data['nama']; ?></p>
            <p><strong>Tanggal Lahir:</strong> <?php echo $data['tanggal_lahir']; ?></p>
            <p><strong>Kota Lahir:</strong> <?php echo $data['kota_lahir']; ?></p>
        <?php else: ?>
            <p>Data anggota tidak ditemukan.</p>
        <?php endif; ?>
        <a href="index.php" class="btn btn-primary">Kembali</a>
    </div>
</div>
