<div class="card">
    <div class="card-header">
        <h2>Daftar Anggota</h2>
    </div>
    <div class="card-body">
        <a href="index.php?action=create" class="btn btn-success mb-3">Tambah Anggota</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Tanggal Lahir</th>
                    <th>Kota Lahir</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $anggota): ?>
                    <tr>
                        <td><?php echo $anggota['id']; ?></td>
                        <td><?php echo $anggota['nama']; ?></td>
                        <td><?php echo $anggota['tanggal_lahir']; ?></td>
                        <td><?php echo $anggota['kota_lahir']; ?></td>
                        <td>
                            <a href="index.php?action=detail&id=<?php echo $anggota['id']; ?>" class="btn btn-info btn-sm">Detail</a>
                            <a href="index.php?action=edit&id=<?php echo $anggota['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="index.php?action=delete&id=<?php echo $anggota['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus anggota ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
