<div class="card">
    <div class="card-header">
        <h2><?php echo isset($data) ? 'Edit Anggota' : 'Tambah Anggota'; ?></h2>
    </div>
    <div class="card-body">
        <form method="post" action="">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo isset($data) ? $data['nama'] : ''; ?>">
            </div>
            <div class="mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir:</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo isset($data) ? $data['tanggal_lahir'] : ''; ?>">
            </div>
            <div class="mb-3">
                <label for="kota_lahir" class="form-label">Kota Lahir:</label>
                <input type="text" class="form-control" id="kota_lahir" name="kota_lahir" value="<?php echo isset($data) ? $data['kota_lahir'] : ''; ?>">
            </div>
            <button type="submit" class="btn btn-success">Simpan</button>
        </form>
        <a href="index.php" class="btn btn-primary mt-3">Kembali</a>
    </div>
</div>
