<?php
// file: oopmvc/controller/Anggota.php
require_once 'model/anggota_model.php';

class Anggota {
    private $model;

    public function __construct() {
        $this->model = new AnggotaModel();
    }

    public function index() {
        $data = $this->model->getAllAnggota();
        $view = 'anggota/list.php';
        require_once 'view/template.php';
    }

    public function detail($id) {
        if ($id === null) {
            echo "ID tidak ditemukan.";
            return;
        }
        $data = $this->model->getAnggotaById($id);
        if ($data === false) {
            echo "Anggota tidak ditemukan.";
            return;
        }
        $view = 'anggota/detail.php';
        require_once 'view/template.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->createAnggota($_POST);
            header('Location: index.php');
        }
        $view = 'anggota/input.php';
        require_once 'view/template.php';
    }

    public function edit($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->updateAnggota($id, $_POST);
            header('Location: index.php');
        }
        $data = $this->model->getAnggotaById($id);
        $view = 'anggota/input.php';
        require_once 'view/template.php';
    }

    public function delete($id) {
        $this->model->deleteAnggota($id);
        header('Location: index.php');
    }
}
?>
