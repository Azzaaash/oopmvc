<?php
// file: oopmvc/detail.php
require_once 'controller/Anggota.php';

$controller = new Anggota();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $controller->detail($id);
} else {
    echo "ID tidak ditemukan.";
}
?>
