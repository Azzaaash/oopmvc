<?php
// file: oopmvc/model/AnggotaModel.php
require_once 'lib/Database.php';

class AnggotaModel extends Database {
    public function getAllAnggota() {
        $db = $this->openDbConnection();
        $stmt = $db->prepare("SELECT * FROM anggota");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->closeDbConnection();
        return $result;
    }

    public function getAnggotaById($id) {
        $db = $this->openDbConnection();
        $stmt = $db->prepare("SELECT * FROM anggota WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->closeDbConnection();
        return $result;
    }

    public function createAnggota($data) {
        $db = $this->openDbConnection();
        $stmt = $db->prepare("INSERT INTO anggota (nama, tanggal_lahir, kota_lahir) VALUES (:nama, :tanggal_lahir, :kota_lahir)");
        $stmt->bindParam(':nama', $data['nama']);
        $stmt->bindParam(':tanggal_lahir', $data['tanggal_lahir']);
        $stmt->bindParam(':kota_lahir', $data['kota_lahir']);
        $stmt->execute();
        $this->closeDbConnection();
    }

    public function updateAnggota($id, $data) {
        $db = $this->openDbConnection();
        $stmt = $db->prepare("UPDATE anggota SET nama = :nama, tanggal_lahir = :tanggal_lahir, kota_lahir = :kota_lahir WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nama', $data['nama']);
        $stmt->bindParam(':tanggal_lahir', $data['tanggal_lahir']);
        $stmt->bindParam(':kota_lahir', $data['kota_lahir']);
        $stmt->execute();
        $this->closeDbConnection();
    }

    public function deleteAnggota($id) {
        $db = $this->openDbConnection();
        $stmt = $db->prepare("DELETE FROM anggota WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $this->closeDbConnection();
    }
}
?>
